"""Опциональный кэш Redis для тяжёлых агрегатов (статистика/аналитика).

По умолчанию ВЫКЛЮЧЕН (REDIS_ENABLED=False). При выключенном или недоступном
Redis всё работает напрямую без кэша — приложение не зависит от Redis.

Инвалидация — по версии: каждая запись в журнал увеличивает счётчик rag:ver,
из-за чего ключи кэша «протухают» мгновенно (а TTL лишь ограничивает память).
"""
from __future__ import annotations
import json
import threading
import time

_client = None
_client_key = None          # параметры подключения, под которые создан клиент
_last_check = 0.0           # когда последний раз проверяли живость клиента
_HEALTH_EVERY = 10.0        # как часто перепроверять живость (сек)
_lock = threading.Lock()


def _cfg():
    import settings
    return settings


def norm_q(s: str) -> str:
    """Нормализация вопроса для КЛЮЧА кэша (не для самого запроса): тримминг,
    схлопывание пробелов, нижний регистр. Повышает попадания в кэш на мелких
    вариациях («Цена X» и «цена x » → один ключ). На сам поиск/эмбеддинг не влияет."""
    import re
    return re.sub(r"\s+", " ", (s or "").strip()).lower()


def enabled() -> bool:
    try:
        return bool(_cfg().get("REDIS_ENABLED"))
    except Exception:
        return False


def _params():
    s = _cfg()
    return ((s.get("REDIS_HOST") or "127.0.0.1").strip(),
            int(s.get("REDIS_PORT") or 6379),
            int(s.get("REDIS_DB") or 0),
            s.get("REDIS_PASSWORD") or "")


def client():
    """Вернуть живой Redis-клиент или None (если выключен/недоступен/нет модуля).

    Самовосстановление: закэшированный клиент периодически перепроверяется ping-ом,
    и при сбое (например, Redis перезапустился или поднялся позже приложения)
    пересоздаётся автоматически — без ручного вмешательства."""
    global _client, _client_key, _last_check
    if not enabled():
        return None
    key = _params()
    with _lock:
        now = time.time()
        if _client is not None and _client_key == key:
            if now - _last_check < _HEALTH_EVERY:
                return _client                      # недавно проверяли — не дёргаем Redis
            try:
                _client.ping()                      # клиент жив?
                _last_check = now
                return _client
            except Exception:
                _client = None                      # протух — переподключимся ниже
        try:
            import redis
        except Exception:
            _client = None
            return None
        host, port, db, pw = key
        try:
            c = redis.Redis(host=host, port=port, db=db, password=pw or None,
                            socket_connect_timeout=2, socket_timeout=2,
                            retry_on_timeout=True, health_check_interval=15,
                            decode_responses=True)
            c.ping()
            _client, _client_key, _last_check = c, key, now
            return c
        except Exception:
            _client = None
            return None


# Версии кэша по «пространствам имён» (ns). Разделены, чтобы инвалидация была точечной:
#   stats — растёт при любой записи в журнал (статистика/аналитика);
#   index — растёт при переиндексации/сбросе индекса (поиск/ответы/каталог);
#   embed — эмбеддинги запроса (ключ уже включает модель → версию не трогаем);
#   live  — короткоживущие снимки (system_info и т.п.; только TTL, версию не трогаем).
_ver_local: dict = {}


def _ver(ns: str = "stats") -> int:
    c = client()
    if not c:
        return _ver_local.get(ns, 0)
    try:
        return int(c.get(f"rag:ver:{ns}") or 0)
    except Exception:
        return _ver_local.get(ns, 0)


def bump(ns: str = "stats") -> None:
    """Инвалидировать кэш пространства ns. По умолчанию stats (запись в журнал).
    При переиндексации/сбросе вызывайте bump('index')."""
    _ver_local[ns] = _ver_local.get(ns, 0) + 1
    c = client()
    if c:
        try:
            c.incr(f"rag:ver:{ns}")
        except Exception:
            pass


def _key(name: str, ns: str) -> str:
    return f"rag:cache:{ns}:{name}:{_ver(ns)}"


def get_or_set(name: str, ttl: int, producer, ns: str = "stats"):
    """Вернуть кэш по ключу name или вычислить producer() и закэшировать на ttl сек.
    ns — пространство имён инвалидации (stats|index|embed|live)."""
    c = client()
    if not c:
        return producer()
    key = _key(name, ns)
    try:
        v = c.get(key)
        if v is not None:
            return json.loads(v)
    except Exception:
        return producer()
    val = producer()
    try:
        c.setex(key, ttl, json.dumps(val, ensure_ascii=False))
    except Exception:
        pass
    return val


def get_json(name: str, ns: str = "index"):
    """Прямое чтение из кэша (None — нет/недоступен). Для ручного кэша ответов."""
    c = client()
    if not c:
        return None
    try:
        v = c.get(_key(name, ns))
        return json.loads(v) if v is not None else None
    except Exception:
        return None


def set_json(name: str, ttl: int, value, ns: str = "index") -> None:
    """Прямая запись в кэш (тихо игнорируется, если Redis недоступен)."""
    c = client()
    if not c:
        return
    try:
        c.setex(_key(name, ns), ttl, json.dumps(value, ensure_ascii=False))
    except Exception:
        pass


# ---- семантический кэш ответов (похожие вопросы) ----
# Список последних ответов: {k: ключ payload в обычном кэше, e: эмбеддинг вопроса}.
# Живёт в пространстве index (сбрасывается при переиндексации). Эмбеддинги bge
# нормализованы, поэтому косинус = скалярное произведение.
_ANS_SEM_MAX = 400


def _anssem_key() -> str:
    return f"rag:anssem:{_ver('index')}"


def _flt_sig(flt) -> str:
    """Каноническая подпись фильтров для сопоставления (порядок ключей не важен)."""
    if not flt:
        return ""
    try:
        return json.dumps(flt, ensure_ascii=False, sort_keys=True)
    except Exception:
        return str(flt)


def answer_sem_add(payload_key: str, emb, flt=None) -> None:
    """Запомнить, что на вопрос с эмбеддингом emb (и фильтрами flt) есть ответ под ключом
    payload_key. Фильтры сохраняются рядом, чтобы семантический поиск не смешивал ответы,
    полученные под разными фильтрами."""
    c = client()
    if not c or not emb or not payload_key:
        return
    try:
        emb = [round(float(x), 6) for x in emb]
        k = _anssem_key()
        c.lpush(k, json.dumps({"k": payload_key, "e": emb, "f": _flt_sig(flt)},
                              ensure_ascii=False))
        c.ltrim(k, 0, _ANS_SEM_MAX - 1)
        c.expire(k, 7 * 86400)
    except Exception:
        pass


def answer_sem_find(emb, threshold: float, flt=None):
    """Найти ключ похожего вопроса (косинус ≥ threshold) с ТЕМИ ЖЕ фильтрами flt, или None.
    → {key, sim}. Записи с иными фильтрами игнорируются, чтобы ответ под одними условиями
    не «утекал» на вопрос с другими/без фильтров."""
    c = client()
    if not c or not emb:
        return None
    try:
        rows = c.lrange(_anssem_key(), 0, _ANS_SEM_MAX - 1)
    except Exception:
        return None
    n = len(emb)
    want = _flt_sig(flt)
    best, bkey = 0.0, None
    for r in rows:
        try:
            d = json.loads(r)
            e = d.get("e")
        except Exception:
            continue
        if not e or len(e) != n:
            continue
        # старые записи без поля "f" считаем «без фильтров» (обратная совместимость)
        if d.get("f", "") != want:
            continue
        dot = 0.0
        for i in range(n):
            dot += emb[i] * e[i]
        if dot > best:
            best, bkey = dot, d.get("k")
    if bkey and best >= float(threshold):
        return {"key": bkey, "sim": round(best, 3)}
    return None


def clear() -> int:
    """Удалить все кэш-ключи приложения. Возвращает число удалённых ключей."""
    c = client()
    if not c:
        return 0
    n = 0
    try:
        for k in c.scan_iter("rag:cache:*"):
            c.delete(k)
            n += 1
        for ns in ("stats", "index"):
            c.incr(f"rag:ver:{ns}")
    except Exception:
        pass
    return n


def status() -> dict:
    en = enabled()
    out = {"enabled": en, "reachable": False, "keys": 0, "error": "",
           "host": "", "version": "", "used_memory": ""}
    if not en:
        return out
    host, port, db, _ = _params()
    out["host"] = f"{host}:{port}/{db}"
    try:
        import redis  # noqa: F401
    except Exception:
        out["error"] = "модуль redis не установлен (pip install redis)"
        return out
    c = client()
    if not c:
        out["error"] = "Redis недоступен по указанному адресу"
        return out
    out["reachable"] = True
    try:
        out["keys"] = sum(1 for _ in c.scan_iter("rag:cache:*"))
        info = c.info()
        out["used_memory"] = info.get("used_memory_human", "")
        out["version"] = info.get("redis_version", "")
        out["mode"] = info.get("redis_mode", "")
        out["clients"] = info.get("connected_clients")
        out["uptime_sec"] = info.get("uptime_in_seconds")
        out["total_keys"] = c.dbsize()
        hits = info.get("keyspace_hits") or 0
        misses = info.get("keyspace_misses") or 0
        out["hits"] = hits
        out["misses"] = misses
        tot = hits + misses
        out["hit_rate"] = round(hits / tot * 100, 1) if tot else None
        out["evicted_keys"] = info.get("evicted_keys")
        out["version_full"] = info.get("redis_version", "")
    except Exception:
        pass
    return out
